import 'screens/flag_game_screen.dart';
import 'screens/result_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'providers/user_provider.dart';
import 'screens/detail_screen.dart';
import 'screens/form_screen.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(FlagQuizApp());
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Jogo das Bandeiras',
      initialRoute: '/form',
      routes: {
        '/form': (context) => const FormScreen(),
        '/game': (context) => const FlagGameScreen(),
        '/result': (context) => const ResultScreen(),
      },
    );
  }
}


class FlagQuizApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Jogo das Bandeiras',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: FlagQuizGame(),
    );
  }
}

class FlagQuizGame extends StatefulWidget {
  @override
  _FlagQuizGameState createState() => _FlagQuizGameState();
}

class _FlagQuizGameState extends State<FlagQuizGame> {
  int currentQuestion = 0;
  int score = 0;
  int lives = 3;

  final List<Question> questions = [
    Question(
      imagePath: 'assets/images/acre.png',
      correctAnswer: 'Acre',
      options: ['Ceará', 'Acre', 'São Paulo', 'Bahia'],
    ),

   //  Question(
   //// imagePath: 'assets/images/bahia.png',
    // correctAnswer: 'Bahia',
    //options: ['Bahia', 'Alagoas', 'Maranhao', 'Roraima'],
    //),

     Question(
      imagePath: 'assets/images/ceara.png',
      correctAnswer: 'Ceará',
      options: ['Paraná', 'Goiás ', 'Paraíba', 'Ceará'],
    ),

     Question(
      imagePath: 'assets/images/goiais.png',
      correctAnswer: 'Goiás',
      options: ['Maranhão', 'Goiás ', 'Roraima', 'Piauí'],
    ),
    /* Question(
      imagePath: 'assets/images/es.png',
      correctAnswer: 'Espiríto Santo',
      options: ['Bahia', 'Espiríto Santo ', 'Pará', 'Ceará'],
    ),*/
     Question(
      imagePath: 'assets/images/df.png',
      correctAnswer: 'Distrito Federal',
      options: ['Rio de Janeiro', 'Goiás ', 'Distrito Federal', 'Pernammbuco'],
    ),
     Question(
      imagePath: 'assets/images/rj.png',
      correctAnswer: 'Rio de Janeiro',
      options: ['Amazonas', 'Maranhão ', 'Paraíba', 'Rio de Janeiro'],
    ),
     Question(
      imagePath: 'assets/images/amazonas.png',
      correctAnswer: 'Amazonas',
      options: ['Amapá', 'amazonas', 'Goiás', 'Ceará'],
    ),
     Question(
      imagePath: 'assets/images/sergipe.png',
      correctAnswer: 'sergipe',
      options: ['Paraná', 'Tocantins ', 'Rio de Janeiro', 'sergipe'],
    ),


    // Adicione mais questões aqui
  ];

  void checkAnswer(String selected) {
    if (selected == questions[currentQuestion].correctAnswer) {
      setState(() {
        score++;
        nextQuestion();
      });
    } else {
      setState(() {
        lives--;
        if (lives == 0) {
          _showGameOverDialog();
        } else {
          nextQuestion();
        }
      });
    }
  }

  void nextQuestion() {
    if (currentQuestion < questions.length - 1) {
      currentQuestion++;
    } else {
      currentQuestion = 0; // reinicia
    }
  }

  void _showGameOverDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Fim de Jogo'),
        content: Text('Sua pontuação: $score'),
        actions: [
          TextButton(
            child: Text('Reiniciar'),
            onPressed: () {
              setState(() {
                score = 0;
                lives = 3;
                currentQuestion = 0;
              });
              Navigator.of(context).pop();
            },
          ),
        ],
      ),
    );
  }

  Widget buildHeartIcons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: List.generate(
        3,
        (index) => Icon(
          Icons.favorite,
          color: index < lives ? Colors.red : Colors.grey,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final current = questions[currentQuestion];
    return Scaffold(
      appBar: AppBar(
        title: Text(''),
        backgroundColor: Colors.black,
        actions: [buildHeartIcons()],
      ),
      backgroundColor: Colors.black,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Pontuação: $score',
            style: TextStyle(fontSize: 20),
          ),
          SizedBox(height: 20),
          Image.asset(current.imagePath, height: 200),
          SizedBox(height: 30),
          ...current.options.map((option) {
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 20),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.grey[850],
                  padding: EdgeInsets.symmetric(vertical: 15),
                  textStyle: TextStyle(fontSize: 18),
                ),
                onPressed: () => checkAnswer(option),
                child: Center(child: Text(option)),
              ),
            );
          }).toList(),
        ],
      ),
    );
  }
}

class Question {
  final String imagePath;
  final String correctAnswer;
  final List<String> options;

  Question({
    required this.imagePath,
    required this.correctAnswer,
    required this.options,
  });
}