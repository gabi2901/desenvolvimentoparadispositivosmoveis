import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/user_provider.dart';

class DetailScreen extends StatefulWidget {
  const DetailScreen({super.key});

  @override
  DetailScreenState createState() => DetailScreenState();
}

class DetailScreenState extends State<DetailScreen> {
  final _formKey = GlobalKey<FormState>();
  final _cidadeController = TextEditingController();
  final _observacaoController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<UserProvider>(context);
    _cidadeController.text = user.cidade ?? '';
    _observacaoController.text = user.observacao ?? '';
    return Scaffold(
      appBar: AppBar(title: Text('Detalhes')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _cidadeController,
                decoration: InputDecoration(labelText: 'Cidade'),
                autovalidateMode: AutovalidateMode.onUserInteraction,
                validator: (value) => value!.isEmpty ? 'Campo obrigatório' : null,
              ),
              TextFormField(
                controller: _observacaoController,
                decoration: InputDecoration(labelText: 'Observação'),
                keyboardType: TextInputType.number,
              ),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  ElevatedButton(child: Text('Voltar'), onPressed: () => Navigator.pop(context)),
                  ElevatedButton(
                    child: Text('Salvar'),
                    onPressed: () async {
                      if (_formKey.currentState!.validate()) {
                        final user = Provider.of<UserProvider>(context, listen: false);
                        user.setDetalhes(_cidadeController.text, _observacaoController.text);
                        Navigator.pushNamedAndRemoveUntil(context, '/', (route) => false);
                      }
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _cidadeController.dispose();
    _observacaoController.dispose();
    super.dispose();
  }
}