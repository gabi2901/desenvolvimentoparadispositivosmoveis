import 'package:flutter/material.dart';
import '../models/flag_question.dart';

final List<FlagQuestion> questions = [
  FlagQuestion(
    imagePath: 'assets/images/brasil.png',
    correctAnswer: 'Brasil',
    options: ['Brasil', 'França', 'Itália', 'Alemanha'],
  ),
  FlagQuestion(
    imagePath: 'assets/images/argentina.png',
    correctAnswer: 'Argentina',
    options: ['Alemanha', 'França', 'Brasil', 'Argentina'],
  ),
  FlagQuestion(
    imagePath: 'assets/images/bolivia.png',
    correctAnswer: 'Bolivia',
    options: ['Bolivia', 'Alemanha', 'Brasil', 'México'],
  ),
];

class FlagGameScreen extends StatefulWidget {
  const FlagGameScreen({super.key});

  @override
  _FlagGameScreenState createState() => _FlagGameScreenState();
}

class _FlagGameScreenState extends State<FlagGameScreen> {
  int currentQuestionIndex = 0;
  int score = 0;

  void checkAnswer(String selectedOption) {
    final current = questions[currentQuestionIndex];
    if (selectedOption == current.correctAnswer) {
      score++;
    }

    if (currentQuestionIndex < questions.length - 1) {
      setState(() {
        currentQuestionIndex++;
      });
    } else {
      Navigator.pushNamed(context, '/results', arguments: score);
    }
  }

  @override
  Widget build(BuildContext context) {
    final current = questions[currentQuestionIndex];

    return Scaffold(
      appBar: AppBar(title: Text('Jogo das Bandeiras')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text('Qual é o país desta bandeira?', style: TextStyle(fontSize: 20)),
            SizedBox(height: 20),
            Image.asset(current.imagePath, height: 200),
            SizedBox(height: 20),
            ...current.options.map((option) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: ElevatedButton(
                    onPressed: () => checkAnswer(option),
                    child: Text(option),
                  ),
                )),
          ],
        ),
      ),
    );
  }
}