package com.example.devmob20251_app_ref_t1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
